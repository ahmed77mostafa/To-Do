import 'package:flutter/cupertino.dart';
import 'Task_Model.dart';
import 'Task_Service.dart';

class TaskProvider extends ChangeNotifier {
  TaskModel? taskModel;

  Future<void> getService() async {
    taskModel = await TaskService().getTaskService();
    notifyListeners();
  }
}
