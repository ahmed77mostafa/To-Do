import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'Task_Provider.dart';

class Taskscreen extends StatelessWidget {
  const Taskscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade400,
      appBar: AppBar(
        title: Text(
          "ToDo",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            "Total: 13",
            style: TextStyle(
                fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
          ),
          Card(
              child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Consumer<TaskProvider>(
                    builder: (context, providerObj, child) {
                      if (providerObj.taskModel == null) {
                        providerObj.getService();
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      } else {
                        var tasks = providerObj.taskModel;
                        return Container(
                          height: 700,
                          child: ListView.builder(
                            itemBuilder: (context, index) {
                              Text('${tasks?.todos}');
                            },
                            itemCount: 10,
                          ),
                        );
                      }
                    },
                  )))
        ]),
      ),
    );
  }
}
