import 'package:dio/dio.dart';
import 'Task_Model.dart';

class TaskService {
  Dio dio = Dio();

  Future<TaskModel> getTaskService() async {
    try {
      Response response = await dio.get("https://dummyjson.com/todos/user/13");
      if (response.statusCode == 200) {
        return TaskModel.fromJson(response.data);
      } else {
        throw Exception('Failed to load task data.....');
      }
    } catch (e) {
      throw Exception('Error $e');
    }
  }

  Future<void> addTask({required String newTask}) async {
    try {
      await dio.post('https://jsonplaceholder.typicode.com/posts',
          data: {"todo": newTask, "completed": false, "userId": 13});
    } catch (e) {
      throw Exception(e);
    }
  }
}
